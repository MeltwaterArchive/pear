<?php

$story = new stdClass();