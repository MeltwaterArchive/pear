<?php

namespace DataSift\Storyplayer\ProseLib;

use DataSift\Stone\ExceptionsLib\Exxx_Exception;

class E5xx_StoryTellerException extends Exxx_Exception
{
}